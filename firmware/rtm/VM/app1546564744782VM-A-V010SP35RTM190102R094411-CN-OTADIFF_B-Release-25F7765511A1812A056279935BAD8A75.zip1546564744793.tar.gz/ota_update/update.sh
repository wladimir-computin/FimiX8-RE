#!/bin/sh
# author:zhoufeng 2018.12.21
errorcount=0
donecount=0

comparefile()
{
	ssmd51=$(busybox md5sum $1)
	commd51=${ssmd51%% *}
	ssmd52=$(busybox md5sum $2)
	commd52=${ssmd52%% *}
	
	if [ $commd51 = $commd52 ]
    then
	    return 0
    else
        echo $2" != "$1
        return 1
    fi
}

updatefile()
{
    for file in $(ls $1)
    do
        if [ -d $1"/"$file ]
        then
            updatefile $1"/"$file
        else
	    srcfile=$1"/"$file
        dstfile=${srcfile#*ota_update}
        echo "update "$dstfile >> /etc/log_update.txt
        rm -f $dstfile
	    cp -f $srcfile $dstfile
        fi
    done     
}

checkfile()
{
    for file in $(ls $1)
    do
        if [ -d $1"/"$file ]
        then
            checkfile $1"/"$file
        else
            srcfile=$1"/"$file
            dstfile=${srcfile#*ota_update}
####        echo "comprare "$srcfile" "$dstfile
	        comparefile $srcfile $dstfile
	        if [ $? -eq 1 ]
            then
	    	    rm -f $dstfile
	    	    cp -f $srcfile $dstfile
                echo "redo update "$dstfile >> /etc/log_update.txt
				comparefile $srcfile $dstfile
				if [ $? -eq 1 ]
				then
					errorcount=$(($errorcount+1))
				else
					donecount=$(($donecount+1))
				fi
	        else
				donecount=$(($donecount+1))
                echo "check "$dstfile" ok ." >> /etc/log_update.txt
            fi
		
        fi
    done     
}

updatefile $1
sync
checkfile $1

#rm -f /etc/uvc_update.done
#rm -f /etc/lastlog
#rm -f /etc/lastlog.old
echo "${errorcount}&${donecount}" >> /etc/log_update.txt
echo "${errorcount}&${donecount}" > /tmp/ota_result

echo "*********update complete !***********" >> /etc/log_update.txt

sync
